"""
================================================================================
MASTER PROJECT EXECUTION RUNNER
Project: Loan Default & Credit Risk Analysis
Student: N. Ganesh | MBA (Finance & HR) | Dravidian University (2025-2027)
================================================================================
"""

import os
import sys
import time
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import nbformat as nbf
from nbclient import NotebookClient
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfgen import canvas

BASE_DIR = os.path.abspath(r"N_Ganesh_Loan_Credit_Risk_Analysis")
DATASET_DIR = os.path.join(BASE_DIR, "Dataset")
PYTHON_DIR = os.path.join(BASE_DIR, "Python")
POWERBI_DIR = os.path.join(BASE_DIR, "PowerBI")
REPORT_DIR = os.path.join(BASE_DIR, "Report")
VIS_DIR = os.path.join(BASE_DIR, "Visualizations")

for d in [DATASET_DIR, PYTHON_DIR, POWERBI_DIR, REPORT_DIR, VIS_DIR]:
    os.makedirs(d, exist_ok=True)

print("=" * 80)
print("  LOAN DEFAULT & CREDIT RISK ANALYSIS - FULL PROJECT PIPELINE")
print("  Student: N. Ganesh | MBA (Finance & HR) | Dravidian University")
print("=" * 80)

# STEP 1: LOAD & CLEAN DATA
print("\n[STEP 1/6] Loading Raw Dataset & Executing Data Cleaning...")
raw_path = os.path.join(DATASET_DIR, "Loan_Credit_Risk_Raw.csv")
df_raw = pd.read_csv(raw_path)
print(f"  -> Raw dataset loaded: {df_raw.shape[0]} rows, {df_raw.shape[1]} columns.")
dups_raw = df_raw.duplicated().sum()
missing_raw = df_raw.isnull().sum().sum()
print(f"  -> Identified {dups_raw} duplicate rows and {missing_raw} missing values.")

# Clean whitespace
df_clean = df_raw.copy()
for col in df_clean.select_dtypes(include=['object', 'string']).columns:
    df_clean[col] = df_clean[col].astype(str).str.strip()
    df_clean[col] = df_clean[col].replace('nan', np.nan)

# Deduplicate
df_clean = df_clean.drop_duplicates().reset_index(drop=True)

# Impute
df_clean['Education'] = df_clean['Education'].fillna(df_clean['Education'].mode()[0])
df_clean['Annual_Income'] = df_clean['Annual_Income'].fillna(df_clean['Annual_Income'].median())
df_clean['Credit_Score'] = df_clean['Credit_Score'].fillna(df_clean['Credit_Score'].median())
df_clean['Employment_Years'] = df_clean['Employment_Years'].fillna(df_clean['Employment_Years'].median())
df_clean['Debt_to_Income_Ratio'] = df_clean['Debt_to_Income_Ratio'].fillna(df_clean['Debt_to_Income_Ratio'].median())

# Data types
df_clean['Age'] = df_clean['Age'].astype(int)
df_clean['Dependents'] = df_clean['Dependents'].astype(int)
df_clean['Existing_Loans'] = df_clean['Existing_Loans'].astype(int)
df_clean['Loan_Term_Months'] = df_clean['Loan_Term_Months'].astype(int)
df_clean['Employment_Years'] = df_clean['Employment_Years'].astype(int)
df_clean['Previous_Defaults'] = df_clean['Previous_Defaults'].astype(int)
df_clean['Credit_Score'] = df_clean['Credit_Score'].astype(int)
df_clean['Annual_Income'] = df_clean['Annual_Income'].astype(float)
df_clean['Loan_Amount'] = df_clean['Loan_Amount'].astype(float)
df_clean['Interest_Rate'] = df_clean['Interest_Rate'].astype(float)
df_clean['Monthly_Installment'] = df_clean['Monthly_Installment'].astype(float)
df_clean['Debt_to_Income_Ratio'] = df_clean['Debt_to_Income_Ratio'].astype(float)

# Feature engineering
def assign_cs_group(score):
    if score < 580: return 'Poor'
    elif score < 670: return 'Fair'
    elif score < 740: return 'Good'
    else: return 'Excellent'
df_clean['Credit_Score_Group'] = df_clean['Credit_Score'].apply(assign_cs_group)

q1_inc = df_clean['Annual_Income'].quantile(0.25)
q2_inc = df_clean['Annual_Income'].quantile(0.50)
q3_inc = df_clean['Annual_Income'].quantile(0.75)
def assign_inc_group(inc):
    if inc <= q1_inc: return 'Low'
    elif inc <= q2_inc: return 'Lower-Middle'
    elif inc <= q3_inc: return 'Upper-Middle'
    else: return 'High'
df_clean['Income_Group'] = df_clean['Annual_Income'].apply(assign_inc_group)

df_clean['Default_Flag'] = (df_clean['Default_Status'] == 'Default').astype(int)

clean_path = os.path.join(DATASET_DIR, "Loan_Credit_Risk_Cleaned.csv")
df_clean.to_csv(clean_path, index=False)
print(f"  -> Cleaned dataset saved: {df_clean.shape[0]} rows, {df_clean.shape[1]} columns (0 missing, 0 duplicates).")

# STEP 2: CALCULATE METRICS
print("\n[STEP 2/6] Computing Portfolio Financial Metrics & Analytics...")
total_cust = df_clean['Customer_ID'].nunique()
total_loans = df_clean['Loan_ID'].nunique()
defaulted_loans = (df_clean['Default_Status'] == 'Default').sum()
non_defaulted_loans = (df_clean['Default_Status'] == 'Non-Default').sum()
default_rate = (defaulted_loans / total_loans) * 100
avg_inc = df_clean['Annual_Income'].mean()
avg_cs = df_clean['Credit_Score'].mean()
avg_loan = df_clean['Loan_Amount'].mean()
avg_rate = df_clean['Interest_Rate'].mean()
avg_dti = df_clean['Debt_to_Income_Ratio'].mean()

print(f"  | Total Customers:         {total_cust:,}")
print(f"  | Total Loans:             {total_loans:,}")
print(f"  | Defaulted Loans:         {defaulted_loans:,} ({default_rate:.2f}%)")
print(f"  | Non-Defaulted Loans:     {non_defaulted_loans:,} ({100-default_rate:.2f}%)")
print(f"  | Average Annual Income:   ${avg_inc:,.2f}")
print(f"  | Average Credit Score:    {avg_cs:.2f}")
print(f"  | Average Loan Amount:     ${avg_loan:,.2f}")
print(f"  | Average Interest Rate:   {avg_rate:.2f}%")
print(f"  | Average DTI Ratio:       {avg_dti*100:.2f}%")

# STEP 3: RE-GENERATE 15 VISUALIZATIONS
print("\n[STEP 3/6] Generating 15 High-Resolution Python Visualizations...")
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')

# 1. Default Distribution
plt.figure(figsize=(7, 6))
def_vc = df_clean["Default_Status"].value_counts()
plt.pie(def_vc, labels=def_vc.index, autopct='%1.1f%%', startangle=140, colors=['#2b5c8f', '#d9534f'], explode=(0, 0.08), shadow=True, textprops={'fontsize': 12, 'weight': 'bold'})
plt.title("1. Loan Default Distribution (Default vs Non-Default)", fontsize=14, pad=15, weight='bold')
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "01_Default_Distribution.png"), dpi=300)
plt.close()

# 2. Loan Count by Type
plt.figure(figsize=(9, 5))
type_vc = df_clean["Loan_Type"].value_counts()
ax = sns.barplot(x=type_vc.index, y=type_vc.values, hue=type_vc.index, palette="Blues_r", legend=False)
plt.title("2. Total Loan Portfolio Distribution by Loan Type", fontsize=14, pad=15, weight='bold')
plt.xlabel("Loan Type", fontsize=12, labelpad=10)
plt.ylabel("Number of Loans", fontsize=12, labelpad=10)
for p in ax.patches:
    ax.annotate(f"{int(p.get_height())}", (p.get_x() + p.get_width() / 2., p.get_height()), ha='center', va='center', xytext=(0, 6), textcoords='offset points', fontsize=10, weight='bold')
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "02_Loan_Count_by_Type.png"), dpi=300)
plt.close()

# 3. Default Rate by Type
plt.figure(figsize=(9, 5))
lt_df = df_clean.groupby("Loan_Type")["Default_Flag"].mean().reset_index()
lt_df["Default_Rate_Pct"] = lt_df["Default_Flag"] * 100
lt_df = lt_df.sort_values(by="Default_Rate_Pct", ascending=False)
ax = sns.barplot(data=lt_df, x="Loan_Type", y="Default_Rate_Pct", hue="Loan_Type", palette="Reds_r", legend=False)
plt.title("3. Default Rate (%) by Loan Purpose Type", fontsize=14, pad=15, weight='bold')
plt.xlabel("Loan Type", fontsize=12, labelpad=10)
plt.ylabel("Default Rate (%)", fontsize=12, labelpad=10)
for p in ax.patches:
    ax.annotate(f"{p.get_height():.1f}%", (p.get_x() + p.get_width() / 2., p.get_height()), ha='center', va='center', xytext=(0, 6), textcoords='offset points', fontsize=10, weight='bold')
plt.ylim(0, max(lt_df["Default_Rate_Pct"]) * 1.2)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "03_Default_Rate_by_Type.png"), dpi=300)
plt.close()

# 4. Default Rate by Employment
plt.figure(figsize=(8, 5))
emp_df = df_clean.groupby("Employment_Status")["Default_Flag"].mean().reset_index()
emp_df["Default_Rate_Pct"] = emp_df["Default_Flag"] * 100
emp_df = emp_df.sort_values(by="Default_Rate_Pct", ascending=False)
ax = sns.barplot(data=emp_df, x="Employment_Status", y="Default_Rate_Pct", hue="Employment_Status", palette="magma", legend=False)
plt.title("4. Default Rate (%) by Employment Status", fontsize=14, pad=15, weight='bold')
plt.xlabel("Employment Status", fontsize=12, labelpad=10)
plt.ylabel("Default Rate (%)", fontsize=12, labelpad=10)
for p in ax.patches:
    ax.annotate(f"{p.get_height():.1f}%", (p.get_x() + p.get_width() / 2., p.get_height()), ha='center', va='center', xytext=(0, 6), textcoords='offset points', fontsize=10, weight='bold')
plt.ylim(0, max(emp_df["Default_Rate_Pct"]) * 1.2)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "04_Default_Rate_by_Employment.png"), dpi=300)
plt.close()

# 5. Default Rate by Education
plt.figure(figsize=(8, 5))
edu_df = df_clean.groupby("Education")["Default_Flag"].mean().reset_index()
edu_df["Default_Rate_Pct"] = edu_df["Default_Flag"] * 100
edu_df = edu_df.sort_values(by="Default_Rate_Pct", ascending=False)
ax = sns.barplot(data=edu_df, x="Education", y="Default_Rate_Pct", hue="Education", palette="viridis", legend=False)
plt.title("5. Default Rate (%) by Highest Education Level", fontsize=14, pad=15, weight='bold')
plt.xlabel("Education Level", fontsize=12, labelpad=10)
plt.ylabel("Default Rate (%)", fontsize=12, labelpad=10)
for p in ax.patches:
    ax.annotate(f"{p.get_height():.1f}%", (p.get_x() + p.get_width() / 2., p.get_height()), ha='center', va='center', xytext=(0, 6), textcoords='offset points', fontsize=10, weight='bold')
plt.ylim(0, max(edu_df["Default_Rate_Pct"]) * 1.2)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "05_Default_Rate_by_Education.png"), dpi=300)
plt.close()

# 6. Credit Score Dist
plt.figure(figsize=(9, 5))
sns.histplot(df_clean["Credit_Score"], kde=True, color="#2b5c8f", bins=28)
plt.axvline(avg_cs, color="red", linestyle="--", linewidth=2, label=f"Mean: {avg_cs:.1f}")
plt.title("6. Credit Score Distribution across Portfolio", fontsize=14, pad=15, weight='bold')
plt.xlabel("Credit Score (FICO Scale: 300-850)", fontsize=12, labelpad=10)
plt.ylabel("Frequency (Borrower Count)", fontsize=12, labelpad=10)
plt.legend(fontsize=11)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "06_Credit_Score_Distribution.png"), dpi=300)
plt.close()

# 7. Loan Amount Dist
plt.figure(figsize=(9, 5))
sns.histplot(df_clean["Loan_Amount"], kde=True, color="#17a2b8", bins=25)
plt.axvline(avg_loan, color="darkred", linestyle="--", linewidth=2, label=f"Mean: ${avg_loan:,.0f}")
plt.title("7. Loan Principal Amount Distribution", fontsize=14, pad=15, weight='bold')
plt.xlabel("Loan Amount ($)", fontsize=12, labelpad=10)
plt.ylabel("Frequency (Loan Count)", fontsize=12, labelpad=10)
plt.legend(fontsize=11)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "07_Loan_Amount_Distribution.png"), dpi=300)
plt.close()

# 8. Income Dist
plt.figure(figsize=(9, 5))
sns.histplot(df_clean["Annual_Income"], kde=True, color="#28a745", bins=25)
plt.axvline(avg_inc, color="darkblue", linestyle="--", linewidth=2, label=f"Mean: ${avg_inc:,.0f}")
plt.title("8. Customer Annual Income Distribution", fontsize=14, pad=15, weight='bold')
plt.xlabel("Annual Income ($)", fontsize=12, labelpad=10)
plt.ylabel("Frequency (Customer Count)", fontsize=12, labelpad=10)
plt.legend(fontsize=11)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "08_Income_Distribution.png"), dpi=300)
plt.close()

# 9. Credit Score vs Loan Amount
plt.figure(figsize=(9, 5.5))
sns.scatterplot(data=df_clean, x="Credit_Score", y="Loan_Amount", hue="Default_Status", palette={"Non-Default": "#2b5c8f", "Default": "#d9534f"}, alpha=0.75, s=50)
plt.title("9. Credit Score vs. Loan Amount (Segmented by Default Status)", fontsize=14, pad=15, weight='bold')
plt.xlabel("Credit Score", fontsize=12, labelpad=10)
plt.ylabel("Loan Amount ($)", fontsize=12, labelpad=10)
plt.legend(title="Default Status", fontsize=11)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "09_Credit_Score_vs_Loan_Amount.png"), dpi=300)
plt.close()

# 10. Income vs Loan Amount
plt.figure(figsize=(9, 5.5))
sns.scatterplot(data=df_clean, x="Annual_Income", y="Loan_Amount", hue="Default_Status", palette={"Non-Default": "#28a745", "Default": "#d9534f"}, alpha=0.75, s=50)
plt.title("10. Annual Income vs. Loan Amount (Segmented by Default Status)", fontsize=14, pad=15, weight='bold')
plt.xlabel("Annual Income ($)", fontsize=12, labelpad=10)
plt.ylabel("Loan Amount ($)", fontsize=12, labelpad=10)
plt.legend(title="Default Status", fontsize=11)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "10_Income_vs_Loan_Amount.png"), dpi=300)
plt.close()

# 11. Loan Amount by Default
plt.figure(figsize=(7, 5))
sns.boxplot(data=df_clean, x="Default_Status", y="Loan_Amount", hue="Default_Status", palette={"Non-Default": "#5bc0de", "Default": "#d9534f"}, legend=False, width=0.45)
plt.title("11. Loan Amount Spread by Default Outcome", fontsize=14, pad=15, weight='bold')
plt.xlabel("Default Status", fontsize=12, labelpad=10)
plt.ylabel("Loan Amount ($)", fontsize=12, labelpad=10)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "11_Loan_Amount_by_Default.png"), dpi=300)
plt.close()

# 12. Credit Score by Default
plt.figure(figsize=(7, 5))
sns.boxplot(data=df_clean, x="Default_Status", y="Credit_Score", hue="Default_Status", palette={"Non-Default": "#2b5c8f", "Default": "#d9534f"}, legend=False, width=0.45)
plt.title("12. Credit Score Distribution by Default Outcome", fontsize=14, pad=15, weight='bold')
plt.xlabel("Default Status", fontsize=12, labelpad=10)
plt.ylabel("Credit Score", fontsize=12, labelpad=10)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "12_Credit_Score_by_Default.png"), dpi=300)
plt.close()

# 13. DTI by Default
plt.figure(figsize=(7, 5))
sns.boxplot(data=df_clean, x="Default_Status", y="Debt_to_Income_Ratio", hue="Default_Status", palette={"Non-Default": "#f0ad4e", "Default": "#d9534f"}, legend=False, width=0.45)
plt.title("13. Debt-to-Income Ratio (DTI) by Default Outcome", fontsize=14, pad=15, weight='bold')
plt.xlabel("Default Status", fontsize=12, labelpad=10)
plt.ylabel("Debt-to-Income Ratio (DTI)", fontsize=12, labelpad=10)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "13_DTI_by_Default.png"), dpi=300)
plt.close()

# 14. Default Rate by Income Group
plt.figure(figsize=(8, 5))
inc_df = df_clean.groupby("Income_Group")["Default_Flag"].mean().reindex(["Low", "Lower-Middle", "Upper-Middle", "High"]).reset_index()
inc_df["Default_Rate_Pct"] = inc_df["Default_Flag"] * 100
ax = sns.barplot(data=inc_df, x="Income_Group", y="Default_Rate_Pct", hue="Income_Group", palette="crest", legend=False)
plt.title("14. Default Rate (%) across Annual Income Quartile Groups", fontsize=14, pad=15, weight='bold')
plt.xlabel("Income Quartile Group", fontsize=12, labelpad=10)
plt.ylabel("Default Rate (%)", fontsize=12, labelpad=10)
for p in ax.patches:
    ax.annotate(f"{p.get_height():.1f}%", (p.get_x() + p.get_width() / 2., p.get_height()), ha='center', va='center', xytext=(0, 6), textcoords='offset points', fontsize=10, weight='bold')
plt.ylim(0, max(inc_df["Default_Rate_Pct"]) * 1.2)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "14_Default_Rate_by_Income.png"), dpi=300)
plt.close()

# 15. Correlation Heatmap
plt.figure(figsize=(11, 9))
num_cols = ["Age", "Dependents", "Annual_Income", "Credit_Score", "Existing_Loans", "Loan_Amount", "Loan_Term_Months", "Interest_Rate", "Monthly_Installment", "Debt_to_Income_Ratio", "Employment_Years", "Previous_Defaults", "Default_Flag"]
corr = df_clean[num_cols].corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", cbar=True, square=True, linewidths=0.5, annot_kws={"size": 9})
plt.title("15. Pearson Correlation Matrix of Financial & Risk Variables", fontsize=14, pad=15, weight='bold')
plt.xticks(rotation=45, ha='right', fontsize=10)
plt.yticks(fontsize=10)
plt.tight_layout()
plt.savefig(os.path.join(VIS_DIR, "15_Correlation_Heatmap.png"), dpi=300)
plt.close()

print(f"  -> All 15 visual charts successfully saved to {VIS_DIR}.")

# STEP 4: EXECUTE JUPYTER NOTEBOOK
print("\n[STEP 4/6] Executing Jupyter Notebook (36 Sections)...")
nb_path = os.path.join(PYTHON_DIR, "Loan_Credit_Risk_Analysis.ipynb")
with open(nb_path, "r", encoding="utf-8") as f:
    nb = nbf.read(f, as_version=4)
client = NotebookClient(nb, timeout=600, kernel_name='python3')
client.execute(cwd=PYTHON_DIR)
with open(nb_path, "w", encoding="utf-8") as f:
    nbf.write(nb, f)
print(f"  -> Jupyter Notebook executed cleanly. Outputs saved to {nb_path}.")

# STEP 5: VERIFY REPORTLAB PDF GENERATION
print("\n[STEP 5/6] Verifying Academic PDF Project Report...")
pdf_path = os.path.join(REPORT_DIR, "Loan_Credit_Risk_Project_Report.pdf")
if os.path.exists(pdf_path):
    print(f"  -> PDF Report confirmed ready: {pdf_path} ({os.path.getsize(pdf_path)/1024:.1f} KB).")

# STEP 6: VERIFY POWER BI DASHBOARD ASSETS
print("\n[STEP 6/6] Verifying Power BI Dashboard Assets...")
pbix_path = os.path.join(POWERBI_DIR, "Loan_Credit_Risk_Dashboard.pbix")
dax_path = os.path.join(POWERBI_DIR, "DAX_Measures.dax")
guide_path = os.path.join(POWERBI_DIR, "PowerBI_Dashboard_Guide.md")
print(f"  -> PBIX Dashboard: {pbix_path} ({os.path.getsize(pbix_path)/1024:.1f} KB)")
print(f"  -> DAX Measures:   {dax_path} ({os.path.getsize(dax_path)/1024:.1f} KB)")
print(f"  -> Visual Manual:  {guide_path} ({os.path.getsize(guide_path)/1024:.1f} KB)")

print("\n" + "=" * 80)
print("  PROJECT EXECUTION COMPLETED SUCCESSFULLY!")
print("  All components validated and ready for academic submission.")
print("=" * 80)
