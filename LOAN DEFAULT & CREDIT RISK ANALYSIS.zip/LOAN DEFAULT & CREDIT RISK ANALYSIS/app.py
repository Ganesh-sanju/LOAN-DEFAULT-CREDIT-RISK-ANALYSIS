"""
================================================================================
INTERACTIVE WEB APPLICATION: LOAN DEFAULT & CREDIT RISK ANALYTICS
Student: N. Ganesh | MBA (Finance & HR) | Dravidian University (2025-2027)
Run via: streamlit run app.py
================================================================================
"""

import os
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# Page Configuration
st.set_page_config(
    page_title="Loan Default & Credit Risk Analytics Dashboard",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
    <style>
    .main { background-color: #0e1726; color: #ffffff; }
    .kpi-card {
        background-color: #1e293b;
        border: 1px solid #334155;
        border-radius: 8px;
        padding: 16px;
        text-align: center;
        margin-bottom: 10px;
    }
    .kpi-title { font-size: 11px; font-weight: bold; color: #94a3b8; text-transform: uppercase; }
    .kpi-val { font-size: 24px; font-weight: bold; color: #38bdf8; margin-top: 4px; }
    </style>
""", unsafe_allow_html=True)

# Load Cleaned Dataset
DATA_PATH = os.path.join("N_Ganesh_Loan_Credit_Risk_Analysis", "Dataset", "Loan_Credit_Risk_Cleaned.csv")
if not os.path.exists(DATA_PATH):
    DATA_PATH = os.path.join("Dataset", "Loan_Credit_Risk_Cleaned.csv")

@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)

df = load_data()

# Header
st.title("💳 Loan Default & Credit Risk Analytics Dashboard")
st.caption("Executive Credit Risk Monitoring & Portfolio Assessment | Author: **N. Ganesh**, MBA (Finance & HR) | Dravidian University")

# Sidebar Filters
st.sidebar.header("🔍 Portfolio Slicers & Filters")
loan_type_filter = st.sidebar.multiselect("Loan Type", options=df["Loan_Type"].unique(), default=df["Loan_Type"].unique())
credit_filter = st.sidebar.multiselect("Credit Score Group", options=["Poor", "Fair", "Good", "Excellent"], default=["Poor", "Fair", "Good", "Excellent"])
employment_filter = st.sidebar.multiselect("Employment Status", options=df["Employment_Status"].unique(), default=df["Employment_Status"].unique())
region_filter = st.sidebar.multiselect("Region", options=df["Region"].unique(), default=df["Region"].unique())
default_filter = st.sidebar.multiselect("Default Status", options=df["Default_Status"].unique(), default=df["Default_Status"].unique())

# Apply Filters
filtered_df = df[
    (df["Loan_Type"].isin(loan_type_filter)) &
    (df["Credit_Score_Group"].isin(credit_filter)) &
    (df["Employment_Status"].isin(employment_filter)) &
    (df["Region"].isin(region_filter)) &
    (df["Default_Status"].isin(default_filter))
]

if filtered_df.empty:
    st.warning("No records match the active filter criteria. Please adjust your filters.")
    st.stop()

# Top Row KPI Cards
k1, k2, k3, k4, k5, k6, k7 = st.columns(7)

total_cust = filtered_df["Customer_ID"].nunique()
total_loans = filtered_df["Loan_ID"].nunique()
def_count = (filtered_df["Default_Status"] == "Default").sum()
def_rate = (def_count / total_loans) * 100 if total_loans > 0 else 0
avg_loan = filtered_df["Loan_Amount"].mean()
avg_cs = filtered_df["Credit_Score"].mean()
avg_inc = filtered_df["Annual_Income"].mean()

with k1:
    st.markdown(f'<div class="kpi-card"><div class="kpi-title">TOTAL CUSTOMERS</div><div class="kpi-val">{total_cust:,}</div></div>', unsafe_allow_html=True)
with k2:
    st.markdown(f'<div class="kpi-card"><div class="kpi-title">TOTAL LOANS</div><div class="kpi-val">{total_loans:,}</div></div>', unsafe_allow_html=True)
with k3:
    st.markdown(f'<div class="kpi-card"><div class="kpi-title">DEFAULTED LOANS</div><div class="kpi-val" style="color: #f87171;">{def_count:,}</div></div>', unsafe_allow_html=True)
with k4:
    st.markdown(f'<div class="kpi-card"><div class="kpi-title">DEFAULT RATE</div><div class="kpi-val" style="color: #f87171;">{def_rate:.2f}%</div></div>', unsafe_allow_html=True)
with k5:
    st.markdown(f'<div class="kpi-card"><div class="kpi-title">AVG LOAN AMOUNT</div><div class="kpi-val" style="color: #4ade80;">${avg_loan:,.0f}</div></div>', unsafe_allow_html=True)
with k6:
    st.markdown(f'<div class="kpi-card"><div class="kpi-title">AVG CREDIT SCORE</div><div class="kpi-val" style="color: #fbbf24;">{avg_cs:.1f}</div></div>', unsafe_allow_html=True)
with k7:
    st.markdown(f'<div class="kpi-card"><div class="kpi-title">AVG ANNUAL INCOME</div><div class="kpi-val" style="color: #c084fc;">${avg_inc:,.0f}</div></div>', unsafe_allow_html=True)

st.markdown("---")

# Middle Section Visuals
c1, c2, c3 = st.columns([1, 1.2, 1.2])

with c1:
    st.subheader("1. Default Distribution")
    fig1 = px.pie(
        filtered_df, names="Default_Status", hole=0.5,
        color="Default_Status", color_discrete_map={"Non-Default": "#38bdf8", "Default": "#f87171"}
    )
    fig1.update_layout(template="plotly_dark", margin=dict(t=10, b=10, l=10, r=10), height=300)
    st.plotly_chart(fig1, use_container_width=True)

with c2:
    st.subheader("2. Default Rate by Loan Type")
    lt_grp = filtered_df.groupby("Loan_Type")["Default_Flag"].mean().reset_index()
    lt_grp["Default_Rate_Pct"] = lt_grp["Default_Flag"] * 100
    lt_grp = lt_grp.sort_values(by="Default_Rate_Pct", ascending=False)
    fig2 = px.bar(
        lt_grp, x="Loan_Type", y="Default_Rate_Pct", text_auto=".1f",
        color="Default_Rate_Pct", color_continuous_scale="Reds"
    )
    fig2.update_layout(template="plotly_dark", yaxis_title="Default Rate (%)", height=300, margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig2, use_container_width=True)

with c3:
    st.subheader("3. Default Rate by Credit Score Group")
    cs_grp = filtered_df.groupby("Credit_Score_Group")["Default_Flag"].mean().reindex(["Poor", "Fair", "Good", "Excellent"]).reset_index()
    cs_grp["Default_Rate_Pct"] = cs_grp["Default_Flag"] * 100
    fig3 = px.bar(
        cs_grp, x="Credit_Score_Group", y="Default_Rate_Pct", text_auto=".1f",
        color="Credit_Score_Group", color_discrete_map={"Poor": "#f87171", "Fair": "#fb923c", "Good": "#38bdf8", "Excellent": "#4ade80"}
    )
    fig3.update_layout(template="plotly_dark", yaxis_title="Default Rate (%)", height=300, margin=dict(t=10, b=10, l=10, r=10), showlegend=False)
    st.plotly_chart(fig3, use_container_width=True)

# Lower Section Visuals
c4, c5 = st.columns([1.3, 1])

with c4:
    st.subheader("4. Income vs. Loan Amount (by Default Status)")
    fig4 = px.scatter(
        filtered_df, x="Annual_Income", y="Loan_Amount", color="Default_Status",
        color_discrete_map={"Non-Default": "#38bdf8", "Default": "#f87171"},
        hover_data=["Customer_ID", "Credit_Score", "Debt_to_Income_Ratio", "Loan_Type"],
        opacity=0.75
    )
    fig4.update_layout(template="plotly_dark", height=350, margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig4, use_container_width=True)

with c5:
    st.subheader("5. Default Rate by Employment Status")
    emp_grp = filtered_df.groupby("Employment_Status")["Default_Flag"].mean().reset_index()
    emp_grp["Default_Rate_Pct"] = emp_grp["Default_Flag"] * 100
    emp_grp = emp_grp.sort_values(by="Default_Rate_Pct", ascending=False)
    fig5 = px.bar(
        emp_grp, x="Employment_Status", y="Default_Rate_Pct", text_auto=".1f",
        color="Default_Rate_Pct", color_continuous_scale="Magma"
    )
    fig5.update_layout(template="plotly_dark", yaxis_title="Default Rate (%)", height=350, margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig5, use_container_width=True)

# Granular Data Matrix
st.subheader("📋 Loan Portfolio Records & Operational Data View")
st.dataframe(
    filtered_df[[
        "Customer_ID", "Loan_ID", "Loan_Type", "Gender", "Age", "Education",
        "Employment_Status", "Annual_Income", "Credit_Score", "Credit_Score_Group",
        "Loan_Amount", "Interest_Rate", "Debt_to_Income_Ratio", "Previous_Defaults", "Default_Status"
    ]].head(100),
    use_container_width=True,
    height=300
)
