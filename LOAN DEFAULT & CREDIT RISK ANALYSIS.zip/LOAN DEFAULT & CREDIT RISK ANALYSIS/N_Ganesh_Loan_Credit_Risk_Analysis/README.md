# Loan Default & Credit Risk Analysis
### Academic Research & Business Analytics Project
**Master of Business Administration (MBA) in Finance & HR**  
**School of Commerce & Management, Dravidian University**  
**Academic Year:** 2025–2027  
**Author:** N. Ganesh  

---

## 1. Project Overview
In retail banking and credit underwriting, **credit risk** is the potential financial loss resulting from a borrower’s failure to meet scheduled repayment obligations. Unmitigated loan defaults erode institutional net interest margins, deplete regulatory capital reserves, and pose systemic solvency risks.

This submission-ready academic project delivers an end-to-end analytical framework for assessing loan default patterns. By combining **Python 3** (Pandas, NumPy, Matplotlib, Seaborn) for data cleaning, statistical modeling, and feature engineering with **Microsoft Power BI Desktop** (Power Query, DAX) for dynamic visual intelligence, this project converts portfolio transaction records into actionable risk management strategies.

> **Academic Disclaimer:** This project utilizes a calibrated synthetic academic dataset (1,200 unique records) engineered to reflect real-world credit risk relationships. Observed patterns represent statistical associations and do not claim absolute causal determination.

---

## 2. Project Objectives
The primary objectives of this project are:
- **Credit-Risk Monitoring:** Quantify portfolio delinquency rates, loss distributions, and product-level performance.
- **Loan Approval Decisioning:** Establish empirical underwriting benchmarks across Credit Scores, Debt-to-Income (DTI) ratios, and Loan-to-Income multiples.
- **Risk Segmentation:** Group borrowers into distinct creditworthiness bands (`Credit_Score_Group`, `Income_Group`) to highlight risk concentration.
- **Default Prevention:** Identify early-warning stress indicators (e.g., high revolving debts, previous defaults) prior to severe delinquency.
- **Strategic Decision-Making:** Provide executive recommendations for risk-based pricing, collateral requirements, and policy formulation.

---

## 3. Technologies Used
- **Programming & Analysis:** Python 3, Pandas, NumPy
- **Data Visualization:** Matplotlib, Seaborn
- **Development Environments:** Jupyter Notebook (`.ipynb`), VS Code, Google Colab
- **Business Intelligence & Reporting:** Microsoft Power BI Desktop, Power Query, DAX (Data Analysis Expressions)
- **Document Generation:** ReportLab PDF Engine (Automated Academic Report)

---

## 4. Repository & Folder Structure
```text
N_Ganesh_Loan_Credit_Risk_Analysis/
│
├── Dataset/
│   ├── Loan_Credit_Risk_Raw.csv         # Raw dataset containing realistic noise, NaNs, and duplicates
│   ├── Loan_Credit_Risk_Cleaned.csv     # Final cleaned, validated dataset ready for analysis & Power BI
│   └── Data_Dictionary.csv             # Full metadata and column descriptions (27 fields)
│
├── Python/
│   └── Loan_Credit_Risk_Analysis.ipynb  # Complete 36-section Jupyter Notebook with all outputs & charts
│
├── PowerBI/
│   ├── Loan_Credit_Risk_Dashboard.pbix  # Power BI Dashboard file
│   ├── DAX_Measures.dax                 # Clean DAX measure definitions
│   ├── PowerBI_Dashboard_Guide.md       # Step-by-step setup and visual configuration guide
│   └── PowerBI_Dashboard_Preview.png    # High-resolution dashboard layout mockup
│
├── Report/
│   └── Loan_Credit_Risk_Project_Report.pdf  # Comprehensive, submission-ready academic PDF report
│
├── Visualizations/
│   ├── 01_Default_Distribution.png
│   ├── 02_Loan_Count_by_Type.png
│   ├── 03_Default_Rate_by_Type.png
│   ├── 04_Default_Rate_by_Employment.png
│   ├── 05_Default_Rate_by_Education.png
│   ├── 06_Credit_Score_Distribution.png
│   ├── 07_Loan_Amount_Distribution.png
│   ├── 08_Income_Distribution.png
│   ├── 09_Credit_Score_vs_Loan_Amount.png
│   ├── 10_Income_vs_Loan_Amount.png
│   ├── 11_Loan_Amount_by_Default.png
│   ├── 12_Credit_Score_by_Default.png
│   ├── 13_DTI_by_Default.png
│   ├── 14_Default_Rate_by_Income.png
│   └── 15_Correlation_Heatmap.png
│
└── README.md                            # Complete Project Master Documentation
```

---

## 5. Dataset Architecture & Data Dictionary
The dataset contains **1,200 unique records** across **24 raw variables** and **3 engineered feature fields**:

| Column Name | Data Type | Description |
| :--- | :--- | :--- |
| `Customer_ID` | String | Unique identifier assigned to borrower (`CUST_1001`) |
| `Gender` | Categorical | Borrower gender (`Male`, `Female`, `Other`) |
| `Age` | Integer | Borrower age in years (21–65) |
| `Education` | Categorical | Highest education level (`High School`, `Bachelor's`, `Master's`, `Doctorate`) |
| `Employment_Status`| Categorical | Current employment status (`Employed`, `Self-Employed`, `Business`, `Unemployed`) |
| `Marital_Status` | Categorical | Marital status (`Married`, `Single`, `Divorced`) |
| `Dependents` | Integer | Count of financially supported dependents (0–4) |
| `Annual_Income` | Currency ($) | Verified gross annual income ($18,000–$220,000) |
| `Credit_Score` | Integer | Standard FICO bureau credit score (300–850) |
| `Existing_Loans` | Integer | Count of active open credit facilities (0–5) |
| `Loan_ID` | String | Unique loan facility identifier (`LN_5001`) |
| `Loan_Type` | Categorical | Purpose of facility (`Personal`, `Home`, `Auto`, `Education`, `Business`) |
| `Loan_Amount` | Currency ($) | Principal disbursed balance ($4,000–$135,000) |
| `Loan_Term_Months` | Integer | Facility amortization tenure in months (12–240) |
| `Interest_Rate` | Percentage | Annual Percentage Rate (APR: 4.5%–25.0%) |
| `Monthly_Installment`| Currency ($)| Equated Monthly Installment (EMI) |
| `Debt_to_Income_Ratio`| Percentage| Total monthly debt obligations divided by monthly gross income (DTI) |
| `Employment_Years` | Integer | Total professional work experience in years |
| `Previous_Defaults`| Integer | Historical delinquency count on credit record (0–3) |
| `Credit_History` | Categorical | Bureau qualitative classification (`Poor`, `Fair`, `Good`, `Excellent`) |
| `Property_Ownership`| Categorical | Residential status (`Rent`, `Mortgage`, `Own`) |
| `Region` | Categorical | Geographical lending territory (`North`, `South`, `East`, `West`, `Central`) |
| `Loan_Status` | Categorical | Operational account status (`Fully Paid`, `Current`, `Default`, `Charged Off`)|
| `Default_Status` | Categorical | Binary performance classification (`Default`, `Non-Default`) |
| `Credit_Score_Group`| Categorical | **Derived:** `<580` (Poor), `580–669` (Fair), `670–739` (Good), `740+` (Excellent)|
| `Income_Group` | Categorical | **Derived:** Quartile splits (`Low`, `Lower-Middle`, `Upper-Middle`, `High`) |
| `Default_Flag` | Binary | **Derived:** Indicator where `1 = Default`, `0 = Non-Default` |

---

## 6. Step-by-Step Data Cleaning
1. **Initial Inspection:** Analyzed data types, missing value distributions, and summary statistics.
2. **Whitespace Stripping:** Cleansed trailing/leading whitespace and standardized string formatting across all categorical fields.
3. **Missing Value Imputation:**
   - *Categorical (`Education`):* Imputed using the **Mode** (`Bachelor's Degree`) to preserve class proportions.
   - *Numerical (`Annual_Income`, `Credit_Score`, `Employment_Years`, `Debt_to_Income_Ratio`):* Imputed using the **Median** to maintain central tendency without skew from extreme observations.
4. **Duplicate Removal:** Identified and dropped 18 redundant records, reducing raw dataset from 1,218 rows to 1,200 unique records (0 duplicates remaining).
5. **Outlier Assessment:** Applied the **1.5 * IQR** methodology across numerical metrics. Retained high-earning and high-balance records as legitimate financial boundary conditions.
6. **Feature Engineering:** Derived `Credit_Score_Group`, `Income_Group`, and `Default_Flag`.

---

## 7. Portfolio Summary Metrics & Key Findings

### Baseline Portfolio KPIs
- **Total Borrowers:** 1,200
- **Total Loan Facilities:** 1,200
- **Defaulted Accounts:** 258 (**21.50%** Overall Default Rate)
- **Non-Defaulted Accounts:** 942 (**78.50%**)
- **Average Annual Income:** $63,978.33
- **Average Credit Score:** 665.01
- **Average Principal Loan Amount:** $35,092.83
- **Average Interest Rate (APR):** 11.94%
- **Average Debt-to-Income (DTI):** 26.22%

### Category Default Rate Breakdown
- **Credit Score Risk:**
  - *Poor (<580):* **43.78%** default rate (81 / 185)
  - *Fair (580–669):* **27.60%** default rate (122 / 442)
  - *Good (670–739):* **13.50%** default rate (49 / 363)
  - *Excellent (740+):* **2.86%** default rate (6 / 210)
- **Loan Purpose Risk:**
  - *Personal Loan:* **28.02%** (Highest unsecured risk)
  - *Business Loan:* **26.62%**
  - *Education Loan:* **21.23%**
  - *Auto Loan:* **19.83%**
  - *Home Loan:* **12.24%** (Lowest risk due to collateral backing)
- **Employment Risk:**
  - *Unemployed:* **45.00%**
  - *Business / Self-Employed:* **24.16%**
  - *Employed (Salaried):* **18.01%**
- **Income Quartile Risk:**
  - *Low (Q1):* **32.67%**
  - *Lower-Middle (Q2):* **24.00%**
  - *Upper-Middle (Q3):* **18.00%**
  - *High (Q4):* **11.33%**
- **Debt-to-Income (DTI) Leverage:**
  - *High DTI (> 40%):* **38.2%** default rate
  - *Sustainable DTI (<= 40%):* **14.6%** default rate

---

## 8. Python Visualizations
All 15 generated visualizations are available in high-resolution PNG format in `Visualizations/`:

1. `01_Default_Distribution.png` — Pie chart displaying Default (21.5%) vs Non-Default (78.5%).
2. `02_Loan_Count_by_Type.png` — Bar chart showing volume mix across loan purposes.
3. `03_Default_Rate_by_Type.png` — Bar chart with % labels highlighting Personal & Business loan risk.
4. `04_Default_Rate_by_Employment.png` — Bar chart comparing default rates by employment stability.
5. `05_Default_Rate_by_Education.png` — Bar chart illustrating educational attainment vs delinquency.
6. `06_Credit_Score_Distribution.png` — Histogram with KDE showing FICO score distribution (mean 665.0).
7. `07_Loan_Amount_Distribution.png` — Histogram showing principal distribution across facilities.
8. `08_Income_Distribution.png` — Histogram depicting positive lognormal skew of annual income.
9. `09_Credit_Score_vs_Loan_Amount.png` — Scatter plot showing default clusters in low-credit tiers.
10. `10_Income_vs_Loan_Amount.png` — Scatter plot illustrating income-to-loan leverage stress.
11. `11_Loan_Amount_by_Default.png` — Box plot comparing principal balances between cohorts.
12. `12_Credit_Score_by_Default.png` — Box plot demonstrating significant credit score divergence.
13. `13_DTI_by_Default.png` — Box plot verifying elevated DTI among defaulting accounts.
14. `14_Default_Rate_by_Income.png` — Bar chart showing monotonic default decrease across income quartiles.
15. `15_Correlation_Heatmap.png` — Pearson correlation matrix across all numerical and risk indicators.

---

## 9. Power BI Dashboard & DAX Measures
The Power BI solution, titled **"Loan Default & Credit Risk Analytics Dashboard"**, features an executive 3-tier layout:
- **Top Ribbon:** 7 KPI Cards (Total Customers, Total Loans, Defaulted Loans, Default Rate %, Avg Loan Amount, Avg Credit Score, Avg Annual Income).
- **Middle Section:** Default Distribution Donut Chart, Default Rate by Loan Type Bar Chart, and Default Rate by Credit Score Group Column Chart.
- **Lower Section:** Income vs. Loan Amount Scatter Plot, Regional Risk Bar Chart, and granular Loan Details Data Matrix.
- **Interactive Slicers:** Multi-select filtering for Gender, Education, Employment Status, Loan Type, Region, Default Status, and Credit Score Group.

### Implemented DAX Measures (`PowerBI/DAX_Measures.dax`):
```dax
Total Customers = DISTINCTCOUNT(Loan_Credit_Risk_Cleaned[Customer_ID])

Total Loans = DISTINCTCOUNT(Loan_Credit_Risk_Cleaned[Loan_ID])

Defaulted Loans = 
CALCULATE(
    COUNTROWS(Loan_Credit_Risk_Cleaned),
    Loan_Credit_Risk_Cleaned[Default_Status] = "Default"
)

Non-Defaulted Loans = 
CALCULATE(
    COUNTROWS(Loan_Credit_Risk_Cleaned),
    Loan_Credit_Risk_Cleaned[Default_Status] = "Non-Default"
)

Default Rate % = 
DIVIDE(
    [Defaulted Loans],
    [Total Loans],
    0
)

Average Loan Amount = AVERAGE(Loan_Credit_Risk_Cleaned[Loan_Amount])

Average Credit Score = AVERAGE(Loan_Credit_Risk_Cleaned[Credit_Score])

Average Annual Income = AVERAGE(Loan_Credit_Risk_Cleaned[Annual_Income])
```

---

## 10. Business Insights & Strategic Recommendations

### Key Insights:
1. **Credit Score Hegemony:** Credit score is the strongest negative predictor of default. The Poor band (<580) defaults at **43.78%**, more than 15x higher than the Excellent band (**2.86%**).
2. **DTI Critical Threshold:** Borrowers with DTI ratios above 40% exhibit more than **2.6x** higher default rates than borrowers below 40%.
3. **Product Collateral Gap:** Unsecured Personal and Business loans suffer more than double the default rate of collateralized Home Loans.
4. **Historical Recurrence:** Prior default history is strongly associated with future delinquency (>48% default rate for multi-defaulters).

### Strategic Recommendations for Lending Institutions:
1. **Dynamic Bureau Score Cutoffs:** Implement a strict approval floor of 620 for unsecured credit. Require co-signers or collateral for scores between 580 and 620.
2. **Mandatory 40% DTI Cap:** Cap total uncollateralized debt obligations at 40% of verified monthly gross income.
3. **Risk-Based Pricing Adjustments:** Increase APR spreads on unsecured Personal and Business loans to adequately compensate for credit risk.
4. **Early Warning BI Alerts:** Establish automated Power BI alerts tracking customers with falling bureau scores or rising external credit lines.
5. **Enhanced Due Diligence for Past Defaulters:** Mandate manual underwriting reviews and verified asset backing for applicants with prior defaults.

---

## 11. How to Run the Project

### Running the Python Notebook:
1. Ensure Python 3.9+ is installed along with required packages:
   ```bash
   pip install pandas numpy matplotlib seaborn nbformat nbclient reportlab
   ```
2. Navigate to the `Python/` directory and launch Jupyter:
   ```bash
   jupyter notebook Loan_Credit_Risk_Analysis.ipynb
   ```
3. Run all cells sequentially (**Kernel > Restart & Run All**). The notebook will execute without errors, produce all 15 visualizations, compute all metrics, and export the cleaned CSV.

### Opening in Power BI:
1. Launch **Microsoft Power BI Desktop**.
2. Open `PowerBI/Loan_Credit_Risk_Dashboard.pbix` (or import `Dataset/Loan_Credit_Risk_Cleaned.csv` as detailed in `PowerBI/PowerBI_Dashboard_Guide.md`).
3. Add the DAX measures from `PowerBI/DAX_Measures.dax`.
4. Interact with the visual filters and slicers to explore portfolio risk.

---

## 12. Student & Institutional Information
- **Student Name:** N. Ganesh
- **Programme:** Master of Business Administration (MBA - Finance & HR)
- **Department:** School of Commerce & Management
- **Institution:** Dravidian University
- **Academic Year:** 2025–2027
