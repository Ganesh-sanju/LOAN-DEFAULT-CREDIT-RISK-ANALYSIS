# Power BI Dashboard Implementation Guide
## Project: Loan Default & Credit Risk Analytics Dashboard
**Student:** N. Ganesh | **Degree:** MBA (Finance & HR) | **University:** Dravidian University (2025–2027)

---

## 1. Overview & Data Source Connection
This guide provides the exact step-by-step instructions to load the cleaned dataset, configure DAX measures, set up interactive slicers, and build all 11 required visual components in Microsoft Power BI Desktop.

### Data Source File:
- Path: `Dataset/Loan_Credit_Risk_Cleaned.csv`
- Records: 1,200 rows, 27 columns

---

## 2. Step-by-Step Setup in Power BI Desktop

### Step 1: Import Data via Power Query
1. Open **Power BI Desktop**.
2. Click on **Home > Get Data > Text/CSV**.
3. Select `Loan_Credit_Risk_Cleaned.csv` and click **Transform Data**.
4. In **Power Query Editor**, verify column data types:
   - `Customer_ID`, `Loan_ID`, `Gender`, `Education`, `Employment_Status`, `Marital_Status`, `Loan_Type`, `Credit_History`, `Property_Ownership`, `Region`, `Loan_Status`, `Default_Status`, `Credit_Score_Group`, `Income_Group` → **Text**
   - `Age`, `Dependents`, `Credit_Score`, `Existing_Loans`, `Loan_Term_Months`, `Employment_Years`, `Previous_Defaults`, `Default_Flag` → **Whole Number**
   - `Annual_Income`, `Loan_Amount`, `Monthly_Installment` → **Decimal Number / Currency ($)**
   - `Interest_Rate`, `Debt_to_Income_Ratio` → **Decimal Number / Percentage (%)**
5. Click **Close & Apply**.

---

### Step 2: Create DAX Measures
In the **Modeling** tab, click **New Measure** and enter each formula from `DAX_Measures.dax`:
1. `Total Customers = DISTINCTCOUNT(Loan_Credit_Risk_Cleaned[Customer_ID])`
2. `Total Loans = DISTINCTCOUNT(Loan_Credit_Risk_Cleaned[Loan_ID])`
3. `Defaulted Loans = CALCULATE(COUNTROWS(Loan_Credit_Risk_Cleaned), Loan_Credit_Risk_Cleaned[Default_Status] = "Default")`
4. `Non-Defaulted Loans = CALCULATE(COUNTROWS(Loan_Credit_Risk_Cleaned), Loan_Credit_Risk_Cleaned[Default_Status] = "Non-Default")`
5. `Default Rate % = DIVIDE([Defaulted Loans], [Total Loans], 0)` *(Set Formatting to Percentage, 2 decimals)*
6. `Average Loan Amount = AVERAGE(Loan_Credit_Risk_Cleaned[Loan_Amount])` *(Set Formatting to Currency, 0 decimals)*
7. `Average Credit Score = AVERAGE(Loan_Credit_Risk_Cleaned[Credit_Score])` *(Set Formatting to Decimal Number, 1 decimal)*
8. `Average Annual Income = AVERAGE(Loan_Credit_Risk_Cleaned[Annual_Income])` *(Set Formatting to Currency, 0 decimals)*

---

## 3. Dashboard Layout & Visuals Configuration

### Canvas Dimensions & Theme
- **Page Size:** 16:9 (1920 x 1080 px or standard 1280 x 720 px)
- **Background Color:** `#F8F9FA` or `#0F172A` (Financial Slate / Navy Dark)

### Top Header
- **Title Text:** `Loan Default & Credit Risk Analytics Dashboard`
- **Subtitle:** `Executive Risk Monitoring & Portfolio Quality Assessment | MBA Academic Project`

---

### Top Row: 7 KPI Cards
| Card Title | Measure / Field | Display Format |
| :--- | :--- | :--- |
| **Total Customers** | `[Total Customers]` | `1,200` |
| **Total Loans** | `[Total Loans]` | `1,200` |
| **Defaulted Loans** | `[Defaulted Loans]` | `258` |
| **Default Rate %** | `[Default Rate %]` | `21.50%` |
| **Avg Loan Amount** | `[Average Loan Amount]` | `$35,093` |
| **Avg Credit Score** | `[Average Credit Score]` | `665.0` |
| **Avg Annual Income** | `[Average Annual Income]` | `$63,978` |

---

### Middle & Lower Sections: 11 Required Visuals

1. **Loan Default Distribution (Donut Chart)**
   - Legend: `Default_Status`
   - Values: `[Total Loans]`
   - Colors: Non-Default `#2B5C8F`, Default `#D9534F`

2. **Default Rate by Loan Type (Bar Chart)**
   - Y-Axis: `Loan_Type`
   - X-Axis: `[Default Rate %]`
   - Data Labels: Enabled (Shows % on bars)

3. **Default Rate by Employment Status (Bar Chart)**
   - Y-Axis: `Employment_Status`
   - X-Axis: `[Default Rate %]`

4. **Default Rate by Credit Score Group (Column Chart)**
   - X-Axis: `Credit_Score_Group` (Sort: Poor, Fair, Good, Excellent)
   - Y-Axis: `[Default Rate %]`

5. **Default Rate by Income Group (Bar Chart)**
   - Y-Axis: `Income_Group` (Sort: Low, Lower-Middle, Upper-Middle, High)
   - X-Axis: `[Default Rate %]`

6. **Loan Amount by Loan Type (Column Chart)**
   - X-Axis: `Loan_Type`
   - Y-Axis: `Sum of Loan_Amount` or `[Average Loan Amount]`

7. **Average Loan Amount by Region (Bar Chart)**
   - Y-Axis: `Region`
   - X-Axis: `[Average Loan Amount]`

8. **Credit Score Distribution (Binned Histogram / Column Chart)**
   - Create Bin on `Credit_Score` (Bin size: 50)
   - X-Axis: `Credit_Score (bins)`
   - Y-Axis: `[Total Loans]`

9. **Income vs Loan Amount (Scatter Chart)**
   - X-Axis: `Annual_Income`
   - Y-Axis: `Loan_Amount`
   - Legend: `Default_Status`

10. **Loan Details (Table / Matrix)**
    - Fields: `Customer_ID`, `Loan_ID`, `Loan_Type`, `Annual_Income`, `Credit_Score`, `Loan_Amount`, `Debt_to_Income_Ratio`, `Previous_Defaults`, `Default_Status`
    - Conditional Formatting: Background highlight on `Default` status (Soft Red).

11. **Default Distribution / Risk Trend (Risk Matrix / Line Chart)**
    - Visual representation of risk across credit history and past defaults.

---

### Left / Top Filter Area: Interactive Slicers
Add responsive dropdown or tile slicers for:
- `Gender`
- `Education`
- `Employment_Status`
- `Loan_Type`
- `Region`
- `Default_Status`
- `Credit_Score_Group`

All 11 visuals and 7 KPI cards dynamically recalculate based on slicer selections.
